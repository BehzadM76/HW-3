#!/usr/bin/python3
import sys
def main():
    for line in sys.stdin:
        for word in line.split():
            print(word.lower() + "\t" + "1")


if __name__ == "__main__":

    main()
