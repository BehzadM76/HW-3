from __future__ import print_function

import sys
from operator import add
from tempfile import NamedTemporaryFile

from pyspark.sql import SparkSession
from pyspark import SparkContext

if __name__ == "__main__":

    spark = SparkSession\
        .builder\
        .appName("PythonWordCount")\
        .getOrCreate()

    lines = spark.read.text("/user/behzad_mazrouei/file5G.txt").rdd.map(lambda r: r[0])
    counts = lines.flatMap(lambda x: x.split(' ')) \
                  .map(lambda x: (x, 1)) \
                  .reduceByKey(add)
    output = counts.collect()
    for (word, count) in output:
        print(word, count)

    spark.stop()
